﻿namespace Air_Ticket_Management_System
{
    partial class AdminFlightSeats
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnlFlightSeats = new System.Windows.Forms.TableLayoutPanel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblFlightSeatsText = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btnFlightSeatsBack = new System.Windows.Forms.Button();
            this.btnA2 = new System.Windows.Forms.Button();
            this.btnA3 = new System.Windows.Forms.Button();
            this.btnA4 = new System.Windows.Forms.Button();
            this.btnA5 = new System.Windows.Forms.Button();
            this.btnA6 = new System.Windows.Forms.Button();
            this.btnA1 = new System.Windows.Forms.Button();
            this.btnB2 = new System.Windows.Forms.Button();
            this.btnB1 = new System.Windows.Forms.Button();
            this.btnB3 = new System.Windows.Forms.Button();
            this.btnB4 = new System.Windows.Forms.Button();
            this.btnB5 = new System.Windows.Forms.Button();
            this.btnB6 = new System.Windows.Forms.Button();
            this.btnC1 = new System.Windows.Forms.Button();
            this.btnC2 = new System.Windows.Forms.Button();
            this.btnC3 = new System.Windows.Forms.Button();
            this.btnC4 = new System.Windows.Forms.Button();
            this.btnC5 = new System.Windows.Forms.Button();
            this.btnC6 = new System.Windows.Forms.Button();
            this.btnD1 = new System.Windows.Forms.Button();
            this.btnD2 = new System.Windows.Forms.Button();
            this.btnD3 = new System.Windows.Forms.Button();
            this.btnD4 = new System.Windows.Forms.Button();
            this.btnD5 = new System.Windows.Forms.Button();
            this.btnD6 = new System.Windows.Forms.Button();
            this.btnE1 = new System.Windows.Forms.Button();
            this.btnE2 = new System.Windows.Forms.Button();
            this.btnE3 = new System.Windows.Forms.Button();
            this.btnE4 = new System.Windows.Forms.Button();
            this.btnE5 = new System.Windows.Forms.Button();
            this.btnE6 = new System.Windows.Forms.Button();
            this.btnF1 = new System.Windows.Forms.Button();
            this.btnF2 = new System.Windows.Forms.Button();
            this.btnF3 = new System.Windows.Forms.Button();
            this.btnF4 = new System.Windows.Forms.Button();
            this.btnF5 = new System.Windows.Forms.Button();
            this.btnF6 = new System.Windows.Forms.Button();
            this.btnG1 = new System.Windows.Forms.Button();
            this.btnG2 = new System.Windows.Forms.Button();
            this.btnG3 = new System.Windows.Forms.Button();
            this.btnG4 = new System.Windows.Forms.Button();
            this.btnG5 = new System.Windows.Forms.Button();
            this.btnG6 = new System.Windows.Forms.Button();
            this.btnH1 = new System.Windows.Forms.Button();
            this.btnH2 = new System.Windows.Forms.Button();
            this.btnH3 = new System.Windows.Forms.Button();
            this.btnH4 = new System.Windows.Forms.Button();
            this.btnH5 = new System.Windows.Forms.Button();
            this.btnH6 = new System.Windows.Forms.Button();
            this.btnI1 = new System.Windows.Forms.Button();
            this.btnI2 = new System.Windows.Forms.Button();
            this.btnI3 = new System.Windows.Forms.Button();
            this.btnI4 = new System.Windows.Forms.Button();
            this.btnI5 = new System.Windows.Forms.Button();
            this.btnI6 = new System.Windows.Forms.Button();
            this.btnJ1 = new System.Windows.Forms.Button();
            this.btnJ2 = new System.Windows.Forms.Button();
            this.btnJ3 = new System.Windows.Forms.Button();
            this.btnJ4 = new System.Windows.Forms.Button();
            this.btnJ5 = new System.Windows.Forms.Button();
            this.btnJ6 = new System.Windows.Forms.Button();
            this.pnlFlightSeats.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlFlightSeats
            // 
            this.pnlFlightSeats.ColumnCount = 21;
            this.pnlFlightSeats.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.pnlFlightSeats.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 70F));
            this.pnlFlightSeats.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 5F));
            this.pnlFlightSeats.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 70F));
            this.pnlFlightSeats.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 5F));
            this.pnlFlightSeats.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 70F));
            this.pnlFlightSeats.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 5F));
            this.pnlFlightSeats.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 70F));
            this.pnlFlightSeats.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 5F));
            this.pnlFlightSeats.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 70F));
            this.pnlFlightSeats.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 5F));
            this.pnlFlightSeats.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 70F));
            this.pnlFlightSeats.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 5F));
            this.pnlFlightSeats.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 70F));
            this.pnlFlightSeats.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 5F));
            this.pnlFlightSeats.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 70F));
            this.pnlFlightSeats.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 5F));
            this.pnlFlightSeats.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 70F));
            this.pnlFlightSeats.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 5F));
            this.pnlFlightSeats.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 70F));
            this.pnlFlightSeats.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.pnlFlightSeats.Controls.Add(this.panel1, 0, 0);
            this.pnlFlightSeats.Controls.Add(this.panel2, 0, 16);
            this.pnlFlightSeats.Controls.Add(this.btnA2, 1, 4);
            this.pnlFlightSeats.Controls.Add(this.btnA3, 1, 6);
            this.pnlFlightSeats.Controls.Add(this.btnA4, 1, 10);
            this.pnlFlightSeats.Controls.Add(this.btnA5, 1, 12);
            this.pnlFlightSeats.Controls.Add(this.btnA6, 1, 14);
            this.pnlFlightSeats.Controls.Add(this.btnA1, 1, 2);
            this.pnlFlightSeats.Controls.Add(this.btnB2, 3, 4);
            this.pnlFlightSeats.Controls.Add(this.btnB1, 3, 2);
            this.pnlFlightSeats.Controls.Add(this.btnB3, 3, 6);
            this.pnlFlightSeats.Controls.Add(this.btnB4, 3, 10);
            this.pnlFlightSeats.Controls.Add(this.btnB5, 3, 12);
            this.pnlFlightSeats.Controls.Add(this.btnB6, 3, 14);
            this.pnlFlightSeats.Controls.Add(this.btnC1, 5, 2);
            this.pnlFlightSeats.Controls.Add(this.btnC2, 5, 4);
            this.pnlFlightSeats.Controls.Add(this.btnC3, 5, 6);
            this.pnlFlightSeats.Controls.Add(this.btnC4, 5, 10);
            this.pnlFlightSeats.Controls.Add(this.btnC5, 5, 12);
            this.pnlFlightSeats.Controls.Add(this.btnC6, 5, 14);
            this.pnlFlightSeats.Controls.Add(this.btnD1, 7, 2);
            this.pnlFlightSeats.Controls.Add(this.btnD2, 7, 4);
            this.pnlFlightSeats.Controls.Add(this.btnD3, 7, 6);
            this.pnlFlightSeats.Controls.Add(this.btnD4, 7, 10);
            this.pnlFlightSeats.Controls.Add(this.btnD5, 7, 12);
            this.pnlFlightSeats.Controls.Add(this.btnD6, 7, 14);
            this.pnlFlightSeats.Controls.Add(this.btnE1, 9, 2);
            this.pnlFlightSeats.Controls.Add(this.btnE2, 9, 4);
            this.pnlFlightSeats.Controls.Add(this.btnE3, 9, 6);
            this.pnlFlightSeats.Controls.Add(this.btnE4, 9, 10);
            this.pnlFlightSeats.Controls.Add(this.btnE5, 9, 12);
            this.pnlFlightSeats.Controls.Add(this.btnE6, 9, 14);
            this.pnlFlightSeats.Controls.Add(this.btnF1, 11, 2);
            this.pnlFlightSeats.Controls.Add(this.btnF2, 11, 4);
            this.pnlFlightSeats.Controls.Add(this.btnF3, 11, 6);
            this.pnlFlightSeats.Controls.Add(this.btnF4, 11, 10);
            this.pnlFlightSeats.Controls.Add(this.btnF5, 11, 12);
            this.pnlFlightSeats.Controls.Add(this.btnF6, 11, 14);
            this.pnlFlightSeats.Controls.Add(this.btnG1, 13, 2);
            this.pnlFlightSeats.Controls.Add(this.btnG2, 13, 4);
            this.pnlFlightSeats.Controls.Add(this.btnG3, 13, 6);
            this.pnlFlightSeats.Controls.Add(this.btnG4, 13, 10);
            this.pnlFlightSeats.Controls.Add(this.btnG5, 13, 12);
            this.pnlFlightSeats.Controls.Add(this.btnG6, 13, 14);
            this.pnlFlightSeats.Controls.Add(this.btnH1, 15, 2);
            this.pnlFlightSeats.Controls.Add(this.btnH2, 15, 4);
            this.pnlFlightSeats.Controls.Add(this.btnH3, 15, 6);
            this.pnlFlightSeats.Controls.Add(this.btnH4, 15, 10);
            this.pnlFlightSeats.Controls.Add(this.btnH5, 15, 12);
            this.pnlFlightSeats.Controls.Add(this.btnH6, 15, 14);
            this.pnlFlightSeats.Controls.Add(this.btnI1, 17, 2);
            this.pnlFlightSeats.Controls.Add(this.btnI2, 17, 4);
            this.pnlFlightSeats.Controls.Add(this.btnI3, 17, 6);
            this.pnlFlightSeats.Controls.Add(this.btnI4, 17, 10);
            this.pnlFlightSeats.Controls.Add(this.btnI5, 17, 12);
            this.pnlFlightSeats.Controls.Add(this.btnI6, 17, 14);
            this.pnlFlightSeats.Controls.Add(this.btnJ1, 19, 2);
            this.pnlFlightSeats.Controls.Add(this.btnJ2, 19, 4);
            this.pnlFlightSeats.Controls.Add(this.btnJ3, 19, 6);
            this.pnlFlightSeats.Controls.Add(this.btnJ4, 19, 10);
            this.pnlFlightSeats.Controls.Add(this.btnJ5, 19, 12);
            this.pnlFlightSeats.Controls.Add(this.btnJ6, 19, 14);
            this.pnlFlightSeats.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlFlightSeats.Location = new System.Drawing.Point(0, 0);
            this.pnlFlightSeats.Name = "pnlFlightSeats";
            this.pnlFlightSeats.RowCount = 17;
            this.pnlFlightSeats.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 60F));
            this.pnlFlightSeats.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.pnlFlightSeats.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 56F));
            this.pnlFlightSeats.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 5F));
            this.pnlFlightSeats.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 56F));
            this.pnlFlightSeats.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 5F));
            this.pnlFlightSeats.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 56F));
            this.pnlFlightSeats.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 5F));
            this.pnlFlightSeats.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 60F));
            this.pnlFlightSeats.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 5F));
            this.pnlFlightSeats.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 56F));
            this.pnlFlightSeats.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 5F));
            this.pnlFlightSeats.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 56F));
            this.pnlFlightSeats.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 5F));
            this.pnlFlightSeats.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 56F));
            this.pnlFlightSeats.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.pnlFlightSeats.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 66F));
            this.pnlFlightSeats.Size = new System.Drawing.Size(1049, 629);
            this.pnlFlightSeats.TabIndex = 0;
            // 
            // panel1
            // 
            this.pnlFlightSeats.SetColumnSpan(this.panel1, 22);
            this.panel1.Controls.Add(this.lblFlightSeatsText);
            this.panel1.Location = new System.Drawing.Point(3, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1043, 54);
            this.panel1.TabIndex = 60;
            // 
            // lblFlightSeatsText
            // 
            this.lblFlightSeatsText.AutoSize = true;
            this.lblFlightSeatsText.Font = new System.Drawing.Font("Microsoft Sans Serif", 22F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFlightSeatsText.Location = new System.Drawing.Point(351, 10);
            this.lblFlightSeatsText.Name = "lblFlightSeatsText";
            this.lblFlightSeatsText.Size = new System.Drawing.Size(349, 36);
            this.lblFlightSeatsText.TabIndex = 0;
            this.lblFlightSeatsText.Text = "SELECT FLIGHT SEAT";
            this.lblFlightSeatsText.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel2
            // 
            this.pnlFlightSeats.SetColumnSpan(this.panel2, 22);
            this.panel2.Controls.Add(this.btnFlightSeatsBack);
            this.panel2.Location = new System.Drawing.Point(3, 565);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1043, 55);
            this.panel2.TabIndex = 61;
            // 
            // btnFlightSeatsBack
            // 
            this.btnFlightSeatsBack.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFlightSeatsBack.Location = new System.Drawing.Point(428, 4);
            this.btnFlightSeatsBack.Name = "btnFlightSeatsBack";
            this.btnFlightSeatsBack.Size = new System.Drawing.Size(189, 49);
            this.btnFlightSeatsBack.TabIndex = 1;
            this.btnFlightSeatsBack.Text = "Back";
            this.btnFlightSeatsBack.UseVisualStyleBackColor = true;
            this.btnFlightSeatsBack.Click += new System.EventHandler(this.btnFlightSeatsCancle_Click);
            // 
            // btnA2
            // 
            this.btnA2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnA2.Location = new System.Drawing.Point(155, 162);
            this.btnA2.Name = "btnA2";
            this.btnA2.Size = new System.Drawing.Size(64, 50);
            this.btnA2.TabIndex = 62;
            this.btnA2.Text = "A2";
            this.btnA2.UseVisualStyleBackColor = true;
            this.btnA2.Click += new System.EventHandler(this.btnA2_Click);
            // 
            // btnA3
            // 
            this.btnA3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnA3.Location = new System.Drawing.Point(155, 223);
            this.btnA3.Name = "btnA3";
            this.btnA3.Size = new System.Drawing.Size(64, 50);
            this.btnA3.TabIndex = 63;
            this.btnA3.Text = "A3";
            this.btnA3.UseVisualStyleBackColor = true;
            this.btnA3.Click += new System.EventHandler(this.btnA3_Click);
            // 
            // btnA4
            // 
            this.btnA4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnA4.Location = new System.Drawing.Point(155, 349);
            this.btnA4.Name = "btnA4";
            this.btnA4.Size = new System.Drawing.Size(64, 50);
            this.btnA4.TabIndex = 64;
            this.btnA4.Text = "A4";
            this.btnA4.UseVisualStyleBackColor = true;
            this.btnA4.Click += new System.EventHandler(this.btnA4_Click);
            // 
            // btnA5
            // 
            this.btnA5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnA5.Location = new System.Drawing.Point(155, 410);
            this.btnA5.Name = "btnA5";
            this.btnA5.Size = new System.Drawing.Size(64, 50);
            this.btnA5.TabIndex = 65;
            this.btnA5.Text = "A5";
            this.btnA5.UseVisualStyleBackColor = true;
            this.btnA5.Click += new System.EventHandler(this.btnA5_Click);
            // 
            // btnA6
            // 
            this.btnA6.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnA6.Location = new System.Drawing.Point(155, 471);
            this.btnA6.Name = "btnA6";
            this.btnA6.Size = new System.Drawing.Size(64, 50);
            this.btnA6.TabIndex = 66;
            this.btnA6.Text = "A6";
            this.btnA6.UseVisualStyleBackColor = true;
            this.btnA6.Click += new System.EventHandler(this.btnA6_Click);
            // 
            // btnA1
            // 
            this.btnA1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnA1.Location = new System.Drawing.Point(155, 101);
            this.btnA1.Name = "btnA1";
            this.btnA1.Size = new System.Drawing.Size(64, 50);
            this.btnA1.TabIndex = 67;
            this.btnA1.Text = "A1";
            this.btnA1.UseVisualStyleBackColor = true;
            this.btnA1.Click += new System.EventHandler(this.btnA1_Click);
            // 
            // btnB2
            // 
            this.btnB2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnB2.Location = new System.Drawing.Point(230, 162);
            this.btnB2.Name = "btnB2";
            this.btnB2.Size = new System.Drawing.Size(64, 50);
            this.btnB2.TabIndex = 68;
            this.btnB2.Text = "B2";
            this.btnB2.UseVisualStyleBackColor = true;
            this.btnB2.Click += new System.EventHandler(this.btnB2_Click);
            // 
            // btnB1
            // 
            this.btnB1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnB1.Location = new System.Drawing.Point(230, 101);
            this.btnB1.Name = "btnB1";
            this.btnB1.Size = new System.Drawing.Size(64, 50);
            this.btnB1.TabIndex = 69;
            this.btnB1.Text = "B1";
            this.btnB1.UseVisualStyleBackColor = true;
            this.btnB1.Click += new System.EventHandler(this.btnB1_Click);
            // 
            // btnB3
            // 
            this.btnB3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnB3.Location = new System.Drawing.Point(230, 223);
            this.btnB3.Name = "btnB3";
            this.btnB3.Size = new System.Drawing.Size(64, 50);
            this.btnB3.TabIndex = 70;
            this.btnB3.Text = "B3";
            this.btnB3.UseVisualStyleBackColor = true;
            this.btnB3.Click += new System.EventHandler(this.btnB3_Click);
            // 
            // btnB4
            // 
            this.btnB4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnB4.Location = new System.Drawing.Point(230, 349);
            this.btnB4.Name = "btnB4";
            this.btnB4.Size = new System.Drawing.Size(64, 50);
            this.btnB4.TabIndex = 71;
            this.btnB4.Text = "B4";
            this.btnB4.UseVisualStyleBackColor = true;
            this.btnB4.Click += new System.EventHandler(this.btnB4_Click);
            // 
            // btnB5
            // 
            this.btnB5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnB5.Location = new System.Drawing.Point(230, 410);
            this.btnB5.Name = "btnB5";
            this.btnB5.Size = new System.Drawing.Size(64, 50);
            this.btnB5.TabIndex = 72;
            this.btnB5.Text = "B5";
            this.btnB5.UseVisualStyleBackColor = true;
            this.btnB5.Click += new System.EventHandler(this.btnB5_Click);
            // 
            // btnB6
            // 
            this.btnB6.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnB6.Location = new System.Drawing.Point(230, 471);
            this.btnB6.Name = "btnB6";
            this.btnB6.Size = new System.Drawing.Size(64, 50);
            this.btnB6.TabIndex = 73;
            this.btnB6.Text = "B6";
            this.btnB6.UseVisualStyleBackColor = true;
            this.btnB6.Click += new System.EventHandler(this.btnB6_Click);
            // 
            // btnC1
            // 
            this.btnC1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnC1.Location = new System.Drawing.Point(305, 101);
            this.btnC1.Name = "btnC1";
            this.btnC1.Size = new System.Drawing.Size(64, 50);
            this.btnC1.TabIndex = 74;
            this.btnC1.Text = "C1";
            this.btnC1.UseVisualStyleBackColor = true;
            this.btnC1.Click += new System.EventHandler(this.btnC1_Click);
            // 
            // btnC2
            // 
            this.btnC2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnC2.Location = new System.Drawing.Point(305, 162);
            this.btnC2.Name = "btnC2";
            this.btnC2.Size = new System.Drawing.Size(64, 50);
            this.btnC2.TabIndex = 75;
            this.btnC2.Text = "C2";
            this.btnC2.UseVisualStyleBackColor = true;
            this.btnC2.Click += new System.EventHandler(this.btnC2_Click);
            // 
            // btnC3
            // 
            this.btnC3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnC3.Location = new System.Drawing.Point(305, 223);
            this.btnC3.Name = "btnC3";
            this.btnC3.Size = new System.Drawing.Size(64, 50);
            this.btnC3.TabIndex = 76;
            this.btnC3.Text = "C3";
            this.btnC3.UseVisualStyleBackColor = true;
            this.btnC3.Click += new System.EventHandler(this.btnC3_Click);
            // 
            // btnC4
            // 
            this.btnC4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnC4.Location = new System.Drawing.Point(305, 349);
            this.btnC4.Name = "btnC4";
            this.btnC4.Size = new System.Drawing.Size(64, 50);
            this.btnC4.TabIndex = 77;
            this.btnC4.Text = "C4";
            this.btnC4.UseVisualStyleBackColor = true;
            this.btnC4.Click += new System.EventHandler(this.btnC4_Click);
            // 
            // btnC5
            // 
            this.btnC5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnC5.Location = new System.Drawing.Point(305, 410);
            this.btnC5.Name = "btnC5";
            this.btnC5.Size = new System.Drawing.Size(64, 50);
            this.btnC5.TabIndex = 78;
            this.btnC5.Text = "C5";
            this.btnC5.UseVisualStyleBackColor = true;
            this.btnC5.Click += new System.EventHandler(this.btnC5_Click);
            // 
            // btnC6
            // 
            this.btnC6.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnC6.Location = new System.Drawing.Point(305, 471);
            this.btnC6.Name = "btnC6";
            this.btnC6.Size = new System.Drawing.Size(64, 50);
            this.btnC6.TabIndex = 79;
            this.btnC6.Text = "C6";
            this.btnC6.UseVisualStyleBackColor = true;
            this.btnC6.Click += new System.EventHandler(this.btnC6_Click);
            // 
            // btnD1
            // 
            this.btnD1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnD1.Location = new System.Drawing.Point(380, 101);
            this.btnD1.Name = "btnD1";
            this.btnD1.Size = new System.Drawing.Size(64, 50);
            this.btnD1.TabIndex = 80;
            this.btnD1.Text = "D1";
            this.btnD1.UseVisualStyleBackColor = true;
            this.btnD1.Click += new System.EventHandler(this.btnD1_Click);
            // 
            // btnD2
            // 
            this.btnD2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnD2.Location = new System.Drawing.Point(380, 162);
            this.btnD2.Name = "btnD2";
            this.btnD2.Size = new System.Drawing.Size(64, 50);
            this.btnD2.TabIndex = 81;
            this.btnD2.Text = "D2";
            this.btnD2.UseVisualStyleBackColor = true;
            this.btnD2.Click += new System.EventHandler(this.btnD2_Click);
            // 
            // btnD3
            // 
            this.btnD3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnD3.Location = new System.Drawing.Point(380, 223);
            this.btnD3.Name = "btnD3";
            this.btnD3.Size = new System.Drawing.Size(64, 50);
            this.btnD3.TabIndex = 82;
            this.btnD3.Text = "D3";
            this.btnD3.UseVisualStyleBackColor = true;
            this.btnD3.Click += new System.EventHandler(this.btnD3_Click);
            // 
            // btnD4
            // 
            this.btnD4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnD4.Location = new System.Drawing.Point(380, 349);
            this.btnD4.Name = "btnD4";
            this.btnD4.Size = new System.Drawing.Size(64, 50);
            this.btnD4.TabIndex = 83;
            this.btnD4.Text = "D4";
            this.btnD4.UseVisualStyleBackColor = true;
            this.btnD4.Click += new System.EventHandler(this.btnD4_Click);
            // 
            // btnD5
            // 
            this.btnD5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnD5.Location = new System.Drawing.Point(380, 410);
            this.btnD5.Name = "btnD5";
            this.btnD5.Size = new System.Drawing.Size(64, 50);
            this.btnD5.TabIndex = 84;
            this.btnD5.Text = "D5";
            this.btnD5.UseVisualStyleBackColor = true;
            this.btnD5.Click += new System.EventHandler(this.btnD5_Click);
            // 
            // btnD6
            // 
            this.btnD6.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnD6.Location = new System.Drawing.Point(380, 471);
            this.btnD6.Name = "btnD6";
            this.btnD6.Size = new System.Drawing.Size(64, 50);
            this.btnD6.TabIndex = 85;
            this.btnD6.Text = "D6";
            this.btnD6.UseVisualStyleBackColor = true;
            this.btnD6.Click += new System.EventHandler(this.btnD6_Click);
            // 
            // btnE1
            // 
            this.btnE1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnE1.Location = new System.Drawing.Point(455, 101);
            this.btnE1.Name = "btnE1";
            this.btnE1.Size = new System.Drawing.Size(64, 50);
            this.btnE1.TabIndex = 86;
            this.btnE1.Text = "E1";
            this.btnE1.UseVisualStyleBackColor = true;
            this.btnE1.Click += new System.EventHandler(this.btnE1_Click);
            // 
            // btnE2
            // 
            this.btnE2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnE2.Location = new System.Drawing.Point(455, 162);
            this.btnE2.Name = "btnE2";
            this.btnE2.Size = new System.Drawing.Size(64, 50);
            this.btnE2.TabIndex = 87;
            this.btnE2.Text = "E2";
            this.btnE2.UseVisualStyleBackColor = true;
            this.btnE2.Click += new System.EventHandler(this.btnE2_Click);
            // 
            // btnE3
            // 
            this.btnE3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnE3.Location = new System.Drawing.Point(455, 223);
            this.btnE3.Name = "btnE3";
            this.btnE3.Size = new System.Drawing.Size(64, 50);
            this.btnE3.TabIndex = 88;
            this.btnE3.Text = "E3";
            this.btnE3.UseVisualStyleBackColor = true;
            this.btnE3.Click += new System.EventHandler(this.btnE3_Click);
            // 
            // btnE4
            // 
            this.btnE4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnE4.Location = new System.Drawing.Point(455, 349);
            this.btnE4.Name = "btnE4";
            this.btnE4.Size = new System.Drawing.Size(64, 50);
            this.btnE4.TabIndex = 89;
            this.btnE4.Text = "E4";
            this.btnE4.UseVisualStyleBackColor = true;
            this.btnE4.Click += new System.EventHandler(this.btnE4_Click);
            // 
            // btnE5
            // 
            this.btnE5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnE5.Location = new System.Drawing.Point(455, 410);
            this.btnE5.Name = "btnE5";
            this.btnE5.Size = new System.Drawing.Size(64, 50);
            this.btnE5.TabIndex = 90;
            this.btnE5.Text = "E5";
            this.btnE5.UseVisualStyleBackColor = true;
            this.btnE5.Click += new System.EventHandler(this.btnE5_Click);
            // 
            // btnE6
            // 
            this.btnE6.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnE6.Location = new System.Drawing.Point(455, 471);
            this.btnE6.Name = "btnE6";
            this.btnE6.Size = new System.Drawing.Size(64, 50);
            this.btnE6.TabIndex = 91;
            this.btnE6.Text = "E6";
            this.btnE6.UseVisualStyleBackColor = true;
            this.btnE6.Click += new System.EventHandler(this.btnE6_Click);
            // 
            // btnF1
            // 
            this.btnF1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnF1.Location = new System.Drawing.Point(530, 101);
            this.btnF1.Name = "btnF1";
            this.btnF1.Size = new System.Drawing.Size(64, 50);
            this.btnF1.TabIndex = 92;
            this.btnF1.Text = "F1";
            this.btnF1.UseVisualStyleBackColor = true;
            this.btnF1.Click += new System.EventHandler(this.btnF1_Click);
            // 
            // btnF2
            // 
            this.btnF2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnF2.Location = new System.Drawing.Point(530, 162);
            this.btnF2.Name = "btnF2";
            this.btnF2.Size = new System.Drawing.Size(64, 50);
            this.btnF2.TabIndex = 93;
            this.btnF2.Text = "F2";
            this.btnF2.UseVisualStyleBackColor = true;
            this.btnF2.Click += new System.EventHandler(this.btnF2_Click);
            // 
            // btnF3
            // 
            this.btnF3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnF3.Location = new System.Drawing.Point(530, 223);
            this.btnF3.Name = "btnF3";
            this.btnF3.Size = new System.Drawing.Size(64, 50);
            this.btnF3.TabIndex = 94;
            this.btnF3.Text = "F3";
            this.btnF3.UseVisualStyleBackColor = true;
            this.btnF3.Click += new System.EventHandler(this.btnF3_Click);
            // 
            // btnF4
            // 
            this.btnF4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnF4.Location = new System.Drawing.Point(530, 349);
            this.btnF4.Name = "btnF4";
            this.btnF4.Size = new System.Drawing.Size(64, 50);
            this.btnF4.TabIndex = 95;
            this.btnF4.Text = "F4";
            this.btnF4.UseVisualStyleBackColor = true;
            this.btnF4.Click += new System.EventHandler(this.btnF4_Click);
            // 
            // btnF5
            // 
            this.btnF5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnF5.Location = new System.Drawing.Point(530, 410);
            this.btnF5.Name = "btnF5";
            this.btnF5.Size = new System.Drawing.Size(64, 50);
            this.btnF5.TabIndex = 96;
            this.btnF5.Text = "F5";
            this.btnF5.UseVisualStyleBackColor = true;
            this.btnF5.Click += new System.EventHandler(this.btnF5_Click);
            // 
            // btnF6
            // 
            this.btnF6.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnF6.Location = new System.Drawing.Point(530, 471);
            this.btnF6.Name = "btnF6";
            this.btnF6.Size = new System.Drawing.Size(64, 50);
            this.btnF6.TabIndex = 97;
            this.btnF6.Text = "F6";
            this.btnF6.UseVisualStyleBackColor = true;
            this.btnF6.Click += new System.EventHandler(this.btnF6_Click);
            // 
            // btnG1
            // 
            this.btnG1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnG1.Location = new System.Drawing.Point(605, 101);
            this.btnG1.Name = "btnG1";
            this.btnG1.Size = new System.Drawing.Size(64, 50);
            this.btnG1.TabIndex = 98;
            this.btnG1.Text = "G1";
            this.btnG1.UseVisualStyleBackColor = true;
            this.btnG1.Click += new System.EventHandler(this.btnG1_Click);
            // 
            // btnG2
            // 
            this.btnG2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnG2.Location = new System.Drawing.Point(605, 162);
            this.btnG2.Name = "btnG2";
            this.btnG2.Size = new System.Drawing.Size(64, 50);
            this.btnG2.TabIndex = 99;
            this.btnG2.Text = "G2";
            this.btnG2.UseVisualStyleBackColor = true;
            this.btnG2.Click += new System.EventHandler(this.btnG2_Click);
            // 
            // btnG3
            // 
            this.btnG3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnG3.Location = new System.Drawing.Point(605, 223);
            this.btnG3.Name = "btnG3";
            this.btnG3.Size = new System.Drawing.Size(64, 50);
            this.btnG3.TabIndex = 100;
            this.btnG3.Text = "G3";
            this.btnG3.UseVisualStyleBackColor = true;
            this.btnG3.Click += new System.EventHandler(this.btnG3_Click);
            // 
            // btnG4
            // 
            this.btnG4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnG4.Location = new System.Drawing.Point(605, 349);
            this.btnG4.Name = "btnG4";
            this.btnG4.Size = new System.Drawing.Size(64, 50);
            this.btnG4.TabIndex = 101;
            this.btnG4.Text = "G4";
            this.btnG4.UseVisualStyleBackColor = true;
            this.btnG4.Click += new System.EventHandler(this.btnG4_Click);
            // 
            // btnG5
            // 
            this.btnG5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnG5.Location = new System.Drawing.Point(605, 410);
            this.btnG5.Name = "btnG5";
            this.btnG5.Size = new System.Drawing.Size(64, 50);
            this.btnG5.TabIndex = 102;
            this.btnG5.Text = "G5";
            this.btnG5.UseVisualStyleBackColor = true;
            this.btnG5.Click += new System.EventHandler(this.btnG5_Click);
            // 
            // btnG6
            // 
            this.btnG6.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnG6.Location = new System.Drawing.Point(605, 471);
            this.btnG6.Name = "btnG6";
            this.btnG6.Size = new System.Drawing.Size(64, 50);
            this.btnG6.TabIndex = 103;
            this.btnG6.Text = "G6";
            this.btnG6.UseVisualStyleBackColor = true;
            this.btnG6.Click += new System.EventHandler(this.btnG6_Click);
            // 
            // btnH1
            // 
            this.btnH1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnH1.Location = new System.Drawing.Point(680, 101);
            this.btnH1.Name = "btnH1";
            this.btnH1.Size = new System.Drawing.Size(64, 50);
            this.btnH1.TabIndex = 104;
            this.btnH1.Text = "H1";
            this.btnH1.UseVisualStyleBackColor = true;
            this.btnH1.Click += new System.EventHandler(this.btnH1_Click);
            // 
            // btnH2
            // 
            this.btnH2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnH2.Location = new System.Drawing.Point(680, 162);
            this.btnH2.Name = "btnH2";
            this.btnH2.Size = new System.Drawing.Size(64, 50);
            this.btnH2.TabIndex = 105;
            this.btnH2.Text = "H2";
            this.btnH2.UseVisualStyleBackColor = true;
            this.btnH2.Click += new System.EventHandler(this.btnH2_Click);
            // 
            // btnH3
            // 
            this.btnH3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnH3.Location = new System.Drawing.Point(680, 223);
            this.btnH3.Name = "btnH3";
            this.btnH3.Size = new System.Drawing.Size(64, 50);
            this.btnH3.TabIndex = 106;
            this.btnH3.Text = "H3";
            this.btnH3.UseVisualStyleBackColor = true;
            this.btnH3.Click += new System.EventHandler(this.btnH3_Click);
            // 
            // btnH4
            // 
            this.btnH4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnH4.Location = new System.Drawing.Point(680, 349);
            this.btnH4.Name = "btnH4";
            this.btnH4.Size = new System.Drawing.Size(64, 50);
            this.btnH4.TabIndex = 107;
            this.btnH4.Text = "H4";
            this.btnH4.UseVisualStyleBackColor = true;
            this.btnH4.Click += new System.EventHandler(this.btnH4_Click);
            // 
            // btnH5
            // 
            this.btnH5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnH5.Location = new System.Drawing.Point(680, 410);
            this.btnH5.Name = "btnH5";
            this.btnH5.Size = new System.Drawing.Size(64, 50);
            this.btnH5.TabIndex = 108;
            this.btnH5.Text = "H5";
            this.btnH5.UseVisualStyleBackColor = true;
            this.btnH5.Click += new System.EventHandler(this.btnH5_Click);
            // 
            // btnH6
            // 
            this.btnH6.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnH6.Location = new System.Drawing.Point(680, 471);
            this.btnH6.Name = "btnH6";
            this.btnH6.Size = new System.Drawing.Size(64, 50);
            this.btnH6.TabIndex = 109;
            this.btnH6.Text = "H6";
            this.btnH6.UseVisualStyleBackColor = true;
            this.btnH6.Click += new System.EventHandler(this.btnH6_Click);
            // 
            // btnI1
            // 
            this.btnI1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnI1.Location = new System.Drawing.Point(755, 101);
            this.btnI1.Name = "btnI1";
            this.btnI1.Size = new System.Drawing.Size(64, 50);
            this.btnI1.TabIndex = 110;
            this.btnI1.Text = "I1";
            this.btnI1.UseVisualStyleBackColor = true;
            this.btnI1.Click += new System.EventHandler(this.btnI1_Click);
            // 
            // btnI2
            // 
            this.btnI2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnI2.Location = new System.Drawing.Point(755, 162);
            this.btnI2.Name = "btnI2";
            this.btnI2.Size = new System.Drawing.Size(64, 50);
            this.btnI2.TabIndex = 111;
            this.btnI2.Text = "I2";
            this.btnI2.UseVisualStyleBackColor = true;
            this.btnI2.Click += new System.EventHandler(this.btnI2_Click);
            // 
            // btnI3
            // 
            this.btnI3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnI3.Location = new System.Drawing.Point(755, 223);
            this.btnI3.Name = "btnI3";
            this.btnI3.Size = new System.Drawing.Size(64, 50);
            this.btnI3.TabIndex = 112;
            this.btnI3.Text = "I3";
            this.btnI3.UseVisualStyleBackColor = true;
            this.btnI3.Click += new System.EventHandler(this.btnI3_Click);
            // 
            // btnI4
            // 
            this.btnI4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnI4.Location = new System.Drawing.Point(755, 349);
            this.btnI4.Name = "btnI4";
            this.btnI4.Size = new System.Drawing.Size(64, 50);
            this.btnI4.TabIndex = 113;
            this.btnI4.Text = "I4";
            this.btnI4.UseVisualStyleBackColor = true;
            this.btnI4.Click += new System.EventHandler(this.btnI4_Click);
            // 
            // btnI5
            // 
            this.btnI5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnI5.Location = new System.Drawing.Point(755, 410);
            this.btnI5.Name = "btnI5";
            this.btnI5.Size = new System.Drawing.Size(64, 50);
            this.btnI5.TabIndex = 114;
            this.btnI5.Text = "I5";
            this.btnI5.UseVisualStyleBackColor = true;
            this.btnI5.Click += new System.EventHandler(this.btnI5_Click);
            // 
            // btnI6
            // 
            this.btnI6.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnI6.Location = new System.Drawing.Point(755, 471);
            this.btnI6.Name = "btnI6";
            this.btnI6.Size = new System.Drawing.Size(64, 50);
            this.btnI6.TabIndex = 115;
            this.btnI6.Text = "I6";
            this.btnI6.UseVisualStyleBackColor = true;
            this.btnI6.Click += new System.EventHandler(this.btnI6_Click);
            // 
            // btnJ1
            // 
            this.btnJ1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnJ1.Location = new System.Drawing.Point(830, 101);
            this.btnJ1.Name = "btnJ1";
            this.btnJ1.Size = new System.Drawing.Size(64, 50);
            this.btnJ1.TabIndex = 116;
            this.btnJ1.Text = "J1";
            this.btnJ1.UseVisualStyleBackColor = true;
            this.btnJ1.Click += new System.EventHandler(this.btnJ1_Click);
            // 
            // btnJ2
            // 
            this.btnJ2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnJ2.Location = new System.Drawing.Point(830, 162);
            this.btnJ2.Name = "btnJ2";
            this.btnJ2.Size = new System.Drawing.Size(64, 50);
            this.btnJ2.TabIndex = 117;
            this.btnJ2.Text = "J2";
            this.btnJ2.UseVisualStyleBackColor = true;
            this.btnJ2.Click += new System.EventHandler(this.btnJ2_Click);
            // 
            // btnJ3
            // 
            this.btnJ3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnJ3.Location = new System.Drawing.Point(830, 223);
            this.btnJ3.Name = "btnJ3";
            this.btnJ3.Size = new System.Drawing.Size(64, 50);
            this.btnJ3.TabIndex = 118;
            this.btnJ3.Text = "J3";
            this.btnJ3.UseVisualStyleBackColor = true;
            this.btnJ3.Click += new System.EventHandler(this.btnJ3_Click);
            // 
            // btnJ4
            // 
            this.btnJ4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnJ4.Location = new System.Drawing.Point(830, 349);
            this.btnJ4.Name = "btnJ4";
            this.btnJ4.Size = new System.Drawing.Size(64, 50);
            this.btnJ4.TabIndex = 119;
            this.btnJ4.Text = "J4";
            this.btnJ4.UseVisualStyleBackColor = true;
            this.btnJ4.Click += new System.EventHandler(this.btnJ4_Click);
            // 
            // btnJ5
            // 
            this.btnJ5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnJ5.Location = new System.Drawing.Point(830, 410);
            this.btnJ5.Name = "btnJ5";
            this.btnJ5.Size = new System.Drawing.Size(64, 50);
            this.btnJ5.TabIndex = 120;
            this.btnJ5.Text = "J5";
            this.btnJ5.UseVisualStyleBackColor = true;
            this.btnJ5.Click += new System.EventHandler(this.btnJ5_Click);
            // 
            // btnJ6
            // 
            this.btnJ6.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnJ6.Location = new System.Drawing.Point(830, 471);
            this.btnJ6.Name = "btnJ6";
            this.btnJ6.Size = new System.Drawing.Size(64, 50);
            this.btnJ6.TabIndex = 121;
            this.btnJ6.Text = "J6";
            this.btnJ6.UseVisualStyleBackColor = true;
            this.btnJ6.Click += new System.EventHandler(this.btnJ6_Click);
            // 
            // AdminFlightSeats
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1049, 629);
            this.Controls.Add(this.pnlFlightSeats);
            this.Name = "AdminFlightSeats";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "AdminFlightSeats";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.AdminFlightSeats_FormClosed);
            this.Load += new System.EventHandler(this.AdminFlightSeats_Load);
            this.pnlFlightSeats.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel pnlFlightSeats;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lblFlightSeatsText;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button btnA2;
        private System.Windows.Forms.Button btnA3;
        private System.Windows.Forms.Button btnA4;
        private System.Windows.Forms.Button btnA5;
        private System.Windows.Forms.Button btnA6;
        private System.Windows.Forms.Button btnA1;
        private System.Windows.Forms.Button btnB2;
        private System.Windows.Forms.Button btnB1;
        private System.Windows.Forms.Button btnB3;
        private System.Windows.Forms.Button btnB4;
        private System.Windows.Forms.Button btnB5;
        private System.Windows.Forms.Button btnB6;
        private System.Windows.Forms.Button btnC1;
        private System.Windows.Forms.Button btnC2;
        private System.Windows.Forms.Button btnC3;
        private System.Windows.Forms.Button btnC4;
        private System.Windows.Forms.Button btnC5;
        private System.Windows.Forms.Button btnC6;
        private System.Windows.Forms.Button btnD1;
        private System.Windows.Forms.Button btnD2;
        private System.Windows.Forms.Button btnD3;
        private System.Windows.Forms.Button btnD4;
        private System.Windows.Forms.Button btnD5;
        private System.Windows.Forms.Button btnD6;
        private System.Windows.Forms.Button btnE1;
        private System.Windows.Forms.Button btnE2;
        private System.Windows.Forms.Button btnE3;
        private System.Windows.Forms.Button btnE4;
        private System.Windows.Forms.Button btnE5;
        private System.Windows.Forms.Button btnE6;
        private System.Windows.Forms.Button btnF1;
        private System.Windows.Forms.Button btnF2;
        private System.Windows.Forms.Button btnF3;
        private System.Windows.Forms.Button btnF4;
        private System.Windows.Forms.Button btnF5;
        private System.Windows.Forms.Button btnF6;
        private System.Windows.Forms.Button btnG1;
        private System.Windows.Forms.Button btnG2;
        private System.Windows.Forms.Button btnG3;
        private System.Windows.Forms.Button btnG4;
        private System.Windows.Forms.Button btnG5;
        private System.Windows.Forms.Button btnG6;
        private System.Windows.Forms.Button btnH1;
        private System.Windows.Forms.Button btnH2;
        private System.Windows.Forms.Button btnH3;
        private System.Windows.Forms.Button btnH4;
        private System.Windows.Forms.Button btnH5;
        private System.Windows.Forms.Button btnH6;
        private System.Windows.Forms.Button btnI1;
        private System.Windows.Forms.Button btnI2;
        private System.Windows.Forms.Button btnI3;
        private System.Windows.Forms.Button btnI4;
        private System.Windows.Forms.Button btnI5;
        private System.Windows.Forms.Button btnI6;
        private System.Windows.Forms.Button btnJ1;
        private System.Windows.Forms.Button btnJ2;
        private System.Windows.Forms.Button btnJ3;
        private System.Windows.Forms.Button btnJ4;
        private System.Windows.Forms.Button btnJ5;
        private System.Windows.Forms.Button btnJ6;
        private System.Windows.Forms.Button btnFlightSeatsBack;
    }
}